import cv2
recoginizer = cv2.createLBPHFaceRecognizer()